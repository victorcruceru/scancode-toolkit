_COLOR = None


def get_color():
    return _COLOR


def set_color(value):
    global _COLOR
    _COLOR = value
